//
//  ViewController.swift
//  How_to_use_JSON
//
//  Created by Abhishek Verma on 11/12/17.
//  Copyright © 2017 SWIFT HUB. All rights reserved.
//

import UIKit
import SwiftyJSON
import Alamofire

class ViewController: UICollectionViewController {
    
    var data1 = [[String: AnyObject]]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        self.DATA()
    }
    
    func DATA() {
        let  Url = URL(string: "https://raw.githubusercontent.com/Abhishekverma99/Use-swift-3.0/master/SecondJson")
        Alamofire.request(Url!).validate().responseJSON { (response) in
            if ((response.result.value) != nil) {
                let jsondata = JSON(response.result.value!)
                print(jsondata)
                if let da = jsondata["movies"].arrayObject
                {
                    self.data1 = da as! [[String : AnyObject]]
                }
                if self.data1.count > 0 {
                    self.collectionView?.reloadData()
                }
            }
        }
    }
    
    override func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return data1.count
    }
    override func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "Cell", for: indexPath) as! CollectionViewCell
        let iP = data1[indexPath.row]
        
        cell.NAME.text = iP["name"] as? String
        
        let a = iP["id"] as? Int
        let b = String(describing: a!)
        cell.ID.text = b
        
        cell.DirectorName.text = iP["director"] as? String
        
        let a1 = iP["rating"] as? CGFloat
        let b1 = String(describing: a1!)
        cell.Rating.text = b1
        
        cell.SelectTheater.tag = indexPath.row
        cell.SelectTheater.addTarget(self, action: #selector(ButtonClick(_:)), for: .touchUpInside)
        
        return cell
    }
    
    var inde = UILabel()
    @objc func ButtonClick(_ sender : UIButton)
    {
        inde.text = String(sender.tag)
        self.performSegue(withIdentifier: "ShowTheater", sender: self)
    }
    
        override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
            if segue.identifier == "ShowTheater" {
                let vc = segue.destination as! TableViewController
                vc.indexpath = inde.text!
            }
        }


}

