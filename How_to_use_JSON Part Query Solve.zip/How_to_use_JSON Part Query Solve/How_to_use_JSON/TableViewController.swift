//
//  TableViewController.swift
//  How_to_use_JSON
//
//  Created by Abhishek Verma on 05/02/18.
//  Copyright © 2018 SWIFT HUB. All rights reserved.
//

import UIKit
import SwiftyJSON
import Alamofire

class TableViewController: UITableViewController {

    // this is index of click cell
    var indexpath = String()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        DATA2()
    }
    
    var data155 = [[String: AnyObject]]()
    func DATA2() {
        let  Url = URL(string: "https://raw.githubusercontent.com/Abhishekverma99/Use-swift-3.0/master/SecondJson")
        Alamofire.request(Url!).validate().responseJSON { (response) in
            if ((response.result.value) != nil) {
                let jsondata = JSON(response.result.value!).dictionary
               // print(jsondata!)
                if let da = jsondata!["movies"]?.arrayObject
                {
                    let con = Int(self.indexpath)
                    if let data2 = da[con!] as? [String: Any]
                    {
                        if let data3 = data2["Cinemas"] as? [AnyObject]
                        {
                            print(data3)
                            self.data155 = data3 as! [[String : AnyObject]]
                        }
       
                    }
                }
                if self.data155.count > 0 {
                    self.tableView?.reloadData()
                }
            }
        }
    }
    
    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return data155.count
    }

    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "Celll", for: indexPath) as! CellTableViewCell
        let index = data155[indexPath.row]
        
        cell.cinema.text = index["cinema_name"] as? String
        cell.date.text = index["date"] as? String
        cell.time.text = index["time"] as? String

        return cell
    }


}
